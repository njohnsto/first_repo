from connect import *
import wpf
from System import Windows
from System.Drawing import (Color, ContentAlignment, Font, FontStyle, Point)
from System.Windows.Forms import (Application, BorderStyle, Button, CheckBox, ComboBox, DialogResult, Form, FormBorderStyle, Label, Panel, RadioButton)
#


# Class that sets up a simple dialogue
class DialogueForm(Form):

    _selectedDoseType = None
    _selectedDoseUnit = None
    _selectedVolumeUnit = None
    _selectedDoseEvaluationName = None
    _beamSetNames = None


    @property
    def SelectedDoseType( self ):
        return self._selectedDoseType

    @property
    def SelectedDoseEvaluationName( self ):
        return self._selectedDoseEvaluationName

    @property
    def SelectedClinicalGoalTemplate( self ):
        return self._selectedClinicalGoalTemplate

    def __init__(self, beamSetName, DoseEvalNames, ClinicalGoalTemplateNames):
        self.Text = "Export DVH data to MS Excel"
        self._beamSetName = beamSetName
        self._DoseEvalNames = DoseEvalNames
        self._ClinicalGoalTemplateNames = ClinicalGoalTemplateNames
        self.SelectedDoseEvalName = ''  #Will be returned from the ComboBox
        self.SelectedClinicalGoalTemplateName = 'Plan' #Can be changed by ComboBox
        self.AutoSize = True

        self.FormBorderStyle = FormBorderStyle.FixedDialog
        self.MaximizeBox = False
        self.MinimizeBox = False

        self.setupDoseTypeRadioButtons( beamSetName )
        self.setupDoseEvalComboBox ( DoseEvalNames )
        self.setupClinicalGoalsComboBox ( ClinicalGoalTemplateNames )
        self.setupButtons()

        self.Controls.Add(self.doseTypeRadioPanel)
        self.Controls.Add(self.DoseEvalComboBoxPanel)
        self.Controls.Add(self.CGPanel)

        self.Controls.Add(self.buttonPanel)

        self.ShowDialog()

    def newPanel(self, x, y):
        panel = Panel()
        panel.AutoSize = True
        panel.Location = Point(x, y)
        panel.BorderStyle = BorderStyle.None
        return panel

    def setupDoseTypeRadioButtons(self, beamSetName):
        self.doseTypeRadioPanel = self.newPanel(0, 0)

        self.doseTypeRadioLabel1 = Label()
        self.doseTypeRadioLabel1.Text = "Select dose source:"
        self.doseTypeRadioLabel1.Location = Point(25, 25)
        self.doseTypeRadioLabel1.AutoSize = True
        
        self.doseTypeRadio1 = RadioButton()
        self.doseTypeRadio1.Text = "Plan dose"
        self.doseTypeRadio1.Location = Point(self.doseTypeRadioLabel1.Location.X + 20, self.doseTypeRadioLabel1.Location.Y + 25)
        self.doseTypeRadio1.Checked = True
        self.doseTypeRadio1.Enabled = True
        self.doseTypeRadio1.AutoSize = True

        self.doseTypeRadio2 = RadioButton()
        self.doseTypeRadio2.Text = 'Beam set dose: {0}'.format(beamSetName)
        self.doseTypeRadio2.Location = Point(self.doseTypeRadio1.Location.X, self.doseTypeRadio1.Location.Y + 25)
        self.doseTypeRadio2.Enabled = True
        self.doseTypeRadio2.AutoSize = True

        self.doseTypeRadio3 = RadioButton()
        self.doseTypeRadio3.Text = 'Evaluation Sum Dose: {0}'.format('Composite')
        self.doseTypeRadio3.Location = Point(self.doseTypeRadio2.Location.X, self.doseTypeRadio2.Location.Y + 25)
        self.doseTypeRadio3.AutoSize = True

        self.doseTypeRadioPanel.Controls.Add(self.doseTypeRadioLabel1)
        self.doseTypeRadioPanel.Controls.Add(self.doseTypeRadio1)
        self.doseTypeRadioPanel.Controls.Add(self.doseTypeRadio2)
        self.doseTypeRadioPanel.Controls.Add(self.doseTypeRadio3)

    def setupDoseEvalComboBox(self, DoseEvalNames):
        self.DoseEvalComboBoxPanel = self.newPanel(0, 100)

        self.DoseEvalComboBox = ComboBox()
        self.DoseEvalComboBox.Enabled = True
        self.DoseEvalComboBox.Location = Point(50, 25)
        self.DoseEvalComboBox.Width = 200
        self.DoseEvalComboBox.Items.AddRange(self._DoseEvalNames)
        # Bind the selection action to the right function
        self.DoseEvalComboBox.SelectionChangeCommitted += self.SelectedDoseEvaluation

        self.DoseEvalComboBoxPanel.Controls.Add(self.DoseEvalComboBox)
        #
        #Set default dose sum to point to the last sum in the list, since that's typically what you want anyway
        self.DoseEvalComboBox.SelectedIndex = self.DoseEvalComboBox.FindStringExact(DoseEvalNames[-1])
        self.SelectedDoseEvalName = DoseEvalNames[-1]
        
    def setupClinicalGoalsComboBox(self, ClinicalGoalTemplateNames):
        self.CGPanel = self.newPanel(0,175)
        self.CGLabel = Label()
        self.CGLabel.Text = "Select clinical goals template:"
        self.CGLabel.Location = Point(50, 40)
        self.CGLabel.AutoSize = True
        
        self.CGComboBox = ComboBox()
        self.CGComboBox.Enabled = True
        self.CGComboBox.Location = Point (50, 60)
        self.CGComboBox.Width = 200
        self.CGComboBox.Items.AddRange(self._ClinicalGoalTemplateNames)
        
        #Bind the selection action to the right function
        self.CGComboBox.SelectionChangeCommitted += self.SelectedClinicalGoalTemplate
        #
        self.CGPanel.Controls.Add(self.CGLabel)
        self.CGPanel.Controls.Add(self.CGComboBox)
        #Set the default value to Plan
        self.CGComboBox.SelectedIndex = self.CGComboBox.FindStringExact("Plan")
        

    def SelectedDoseEvaluation(self, sender, event):
        #Save the selected dose sum name
        #self.SelectedDoseEvalName = sender.Text
        self.SelectedDoseEvalName = sender.SelectedItem.ToString()
        return

    def SelectedClinicalGoalTemplate(self, sender, event):
        #Save the selected template name
        self.SelectedClinicalGoalTemplateName = sender.SelectedItem.ToString()

    def okClicked(self, sender, args):
        if self.doseTypeRadio1.Checked:
            self._selectedDoseType = 'Plan dose'

        elif self.doseTypeRadio2.Checked:
            self._selectedDoseType = 'Beam set dose'

        elif self.doseTypeRadio3.Checked:
            self._selectedDoseType = 'Sum dose'

        else:
            raise IOError("Dose type selection failed.")


        self.DialogResult = DialogResult.OK
        self.Dispose

    def cancelClicked(self, sender, args):
        self.DialogResult = DialogResult.Cancel
        self.Dispose

    def setupButtons(self):
        self.buttonPanel = self.newPanel(0, 250)

        okButton = Button()
        okButton.Text = "OK"
        okButton.Location = Point(50, 50)
        self.AcceptButton = okButton
        okButton.Click += self.okClicked
        
        cancelButton = Button()
        cancelButton.Text = "Cancel"
        cancelButton.Location = Point(okButton.Left + okButton.Width + 50, okButton.Top)
        self.CancelButton = cancelButton
        cancelButton.Click += self.cancelClicked

        self.buttonPanel.Controls.Add(okButton)
        self.buttonPanel.Controls.Add(cancelButton)
