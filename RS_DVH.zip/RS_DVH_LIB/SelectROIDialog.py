import os
from connect import *
import wpf
from System import Windows
#
#Retrieve the location of the SCRIPT_DIRECTORY
from RS_DVH_LIB import Globals
SCRIPT_DIRECTORY = Globals.__SCRIPT_DIRECTORY
DIALOG_DIRECTORY = SCRIPT_DIRECTORY + 'RS_DVH_LIB/'
select_dialog_filename = os.path.normpath(DIALOG_DIRECTORY + 'SelectROIDialog.xaml')

class SelectROIDialog(Windows.Window):
    '''Select ROI's out of the ROI object from a plan.'''
    def ok_clicked(self, sender, event):
        self.Selected = self.Selector.SelectedItems
        self.DialogResult = True
  
    def cancel_clicked(self, sender, event):
        self.DialogResult = False

    def __init__(self, patient_name, plan_name, ROIitem_list):    
        wpf.LoadComponent(self, select_dialog_filename)
        self.Title = "SELECT THE ROI's YOU WANT TO EVALUATE"
        #Assign methods to actions
        self.ControlBox = False
        self.Selector.ItemsSource = ROIitem_list
        self.PatientName.Text = patient_name
        self.PlanName.Text = plan_name
        self.OK.Click += self.ok_clicked
        self.Cancel.Click += self.cancel_clicked

class ROI_Selector(object):
    def __init__(self, ROI):
        '''Returns a single ROI item suitable for use in a wpf Selector list'''
        # The complete set of ROIs is from ROIs = case.PatientModel.RegionsOfInterest
        self.index = ROI.RoiNumber
        self.name = ROI.Name
        self.type = ROI.Type
        #Add additional references to match roi properties in RayStation
        self.RoiNumber = self.index
        self.Name = self.name
        self.Type = self.type
        #self.roi = ROI #For convenience, so the actual ROI object can be accessed ***did not need this***
        

