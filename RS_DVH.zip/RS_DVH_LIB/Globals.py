#This module is used to pass global variables to other modules
#It is primarily for making it easier to record the file directory structure
__SCRIPT_DIRECTORY = ""
__XLTM_DIRECTORY = ""
__DEFAULT_WBFN = ""
