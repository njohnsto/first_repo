import wpf
from System import Windows, Globalization
#
#Retrieve the location of the SCRIPT_DIRECTORY
from RS_DVH_LIB import Globals
SCRIPT_DIRECTORY = Globals.__SCRIPT_DIRECTORY
DIALOG_DIRECTORY = SCRIPT_DIRECTORY + 'RS_DVH_LIB/'
select_dialog_filename = os.path.normpath(DIALOG_DIRECTORY + 'SelectROIDialog.xaml')

class SelectDialog(Windows.Window):

    def ok_clicked(self, sender, event):
        self.selected_items = self.Selector.SelectedItems
        self.span = float(self.Span.Text)
        self.dose_level = float(self.DoseLevel.Text)
        self.action = "Run"
        self.DialogResult = True

    def previous_clicked(self, sender, event):
        self.action = "Previous"
        self.DialogResult = True
  
    def cancel_clicked(self, sender, event):
        self.DialogResult = False

    def __init__(self, title, cases):    
        wpf.LoadComponent(self, select_dialog_filename)
        self.Title = title
        self.ControlBox = False
        self.Selector.ItemsSource = cases
        self.OK.Click += self.ok_clicked
        self.Previous.Click += self.previous_clicked
        self.Cancel.Click += self.cancel_clicked

class PatientAndPlan(object):  
    def __init__(self, index, id, patient_name, plan_name, date, approved):
        self.index = index
        self.id = id
        self.patient_name = patient_name
        self.plan_name = plan_name
        self.date = date
        self.date_string = date.ToString("dd MMM yyyy, HH:mm:ss", Globalization.CultureInfo.InvariantCulture)
        self.approved = approved

        
